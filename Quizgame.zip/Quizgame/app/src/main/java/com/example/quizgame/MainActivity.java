package com.example.quizgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button start;
    TextView textView,textView2;
    EditText playername;

    public void JumpQuiz(View view)
    {
        Intent intent=new Intent(this, MainActivity2.class);
        intent.putExtra("username",playername.getText().toString());
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        start=findViewById(R.id.button);
        textView=findViewById(R.id.textView);
        textView2=findViewById(R.id.textView2);
        playername=findViewById(R.id.editTextTextPersonName);

        if(playername!=null)
        {
            Intent intent=getIntent();
            String name=intent.getStringExtra("username");
            playername.setText(name);
        }
    }
}