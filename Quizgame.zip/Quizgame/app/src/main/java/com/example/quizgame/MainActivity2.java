package com.example.quizgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    TextView textView3,textView4;
    ProgressBar progressBar;
    String Q1_response,Q2_response,Q3_response,Q4_response,Q5_response;
    Button button2,button3,button4,button5,button6,button7,button8,button9,button10,button11,
            button12,button13,button14,button15,button16,button17,button18,button19,button20,
            button21,button22,button23,button24,button25;

    int progress = 1;
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        progressBar=findViewById(R.id.progressBar);

        textView3=findViewById(R.id.textView3);
        textView4=findViewById(R.id.textView4);

        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);
        button5=findViewById(R.id.button5);
        button6=findViewById(R.id.button6);
        button7=findViewById(R.id.button7);
        button8=findViewById(R.id.button8);
        button9=findViewById(R.id.button9);
        button10=findViewById(R.id.button10);
        button11=findViewById(R.id.button11);
        button12=findViewById(R.id.button12);
        button13=findViewById(R.id.button13);
        button14=findViewById(R.id.button14);
        button15=findViewById(R.id.button15);
        button16=findViewById(R.id.button16);
        button17=findViewById(R.id.button17);
        button18=findViewById(R.id.button18);
        button19=findViewById(R.id.button19);
        button20=findViewById(R.id.button20);
        button21=findViewById(R.id.button21);
        button22=findViewById(R.id.button22);
        button23=findViewById(R.id.button23);
        button24=findViewById(R.id.button24);
        button25=findViewById(R.id.button25);

        Intent intent = getIntent();
        String name = intent.getStringExtra("username");
        textView3.setText("Welcome "+name +"!" );

        //question 1
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q1_response="Correct";
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q1_response="Wrong1";
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q1_response="Wrong2";
            }
        });

        //question 2
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q2_response="Wrong1";
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q2_response="Wrong2";
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q2_response="Correct";
            }
        });
        //question 3
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q3_response="Wrong1";
            }
        });
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q3_response="Wrong2";
            }
        });
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q3_response="Correct";
            }
        });
        //question 4
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q4_response="Wrong1";
            }
        });
        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q4_response="Correct";
            }
        });
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q4_response="Wrong2";
            }
        });
        //question 5
        button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q5_response="Wrong1";
            }
        });
        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q5_response="Wrong2";
            }
        });
        button21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Q5_response="Correct";
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Q1_response=="Correct")
                {
                    button2.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button6.setEnabled(true);
                    button6.setVisibility(View.VISIBLE);
                    score=score+1;
                }
                else if(Q1_response=="Wrong1")
                {
                    button3.setBackgroundColor(Color.RED);
                    button2.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button6.setEnabled(true);
                    button6.setVisibility(View.VISIBLE);
                }
                else if(Q1_response=="Wrong2")
                {
                    button4.setBackgroundColor(Color.RED);
                    button2.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button6.setEnabled(true);
                    button6.setVisibility(View.VISIBLE);
                }
                else if(Q2_response=="Correct")
                {
                    button9.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button10.setEnabled(true);
                    button10.setVisibility(View.VISIBLE);
                    score=score+1;
                }
                else if(Q2_response=="Wrong1")
                {
                    button7.setBackgroundColor(Color.RED);
                    button9.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button10.setEnabled(true);
                    button10.setVisibility(View.VISIBLE);
                }
                else if(Q2_response=="Wrong2")
                {
                    button8.setBackgroundColor(Color.RED);
                    button9.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button10.setEnabled(true);
                    button10.setVisibility(View.VISIBLE);
                }
                else if(Q3_response=="Correct")
                {
                    button13.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button14.setEnabled(true);
                    button14.setVisibility(View.VISIBLE);
                    score=score+1;
                }
                else if(Q3_response=="Wrong1")
                {
                    button11.setBackgroundColor(Color.RED);
                    button13.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button14.setEnabled(true);
                    button14.setVisibility(View.VISIBLE);
                }
                else if(Q3_response=="Wrong2")
                {
                    button12.setBackgroundColor(Color.RED);
                    button13.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button14.setEnabled(true);
                    button14.setVisibility(View.VISIBLE);
                }
                //question 4
                else if(Q4_response=="Correct")
                {
                    button16.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button18.setEnabled(true);
                    button18.setVisibility(View.VISIBLE);
                    score=score+1;
                }
                else if(Q4_response=="Wrong1")
                {
                    button15.setBackgroundColor(Color.RED);
                    button16.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button18.setEnabled(true);
                    button18.setVisibility(View.VISIBLE);
                }
                else if(Q4_response=="Wrong2")
                {
                    button17.setBackgroundColor(Color.RED);
                    button16.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button18.setEnabled(true);
                    button18.setVisibility(View.VISIBLE);
                }
                //question 5
                else if(Q5_response=="Correct")
                {
                    button21.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button22.setEnabled(true);
                    button22.setVisibility(View.VISIBLE);
                    score=score+1;
                }
                else if(Q5_response=="Wrong1")
                {
                    button19.setBackgroundColor(Color.RED);
                    button21.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button22.setEnabled(true);
                    button22.setVisibility(View.VISIBLE);
                }
                else if(Q5_response=="Wrong2")
                {
                    button20.setBackgroundColor(Color.RED);
                    button21.setBackgroundColor(Color.GREEN);
                    button5.setEnabled(false);
                    button5.setVisibility(View.INVISIBLE);
                    button22.setEnabled(true);
                    button22.setVisibility(View.VISIBLE);
                }
                else
                {
                    Toast.makeText(MainActivity2.this,"Select an option before proceeding",Toast.LENGTH_LONG).show();
                }
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView4.setText("Q2. What house did Sorting hat chose for Harry in Harry Potter?");

                button2.setEnabled(false);
                button3.setEnabled(false);
                button4.setEnabled(false);

                button2.setVisibility(View.INVISIBLE);
                button3.setVisibility(View.INVISIBLE);
                button4.setVisibility(View.INVISIBLE);

                button7.setEnabled(true);
                button8.setEnabled(true);
                button9.setEnabled(true);

                button7.setVisibility(View.VISIBLE);
                button8.setVisibility(View.VISIBLE);
                button9.setVisibility(View.VISIBLE);

                Q1_response=null;

                button5.setEnabled(true);
                button5.setVisibility(View.VISIBLE);
                button6.setEnabled(false);
                button6.setVisibility(View.INVISIBLE);
                progressBar.setProgress((progress + 20));
                progress=progress+20;

            }
        });
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView4.setText("Q3. What is the Superman's planet's name");

                button7.setEnabled(false);
                button8.setEnabled(false);
                button9.setEnabled(false);

                button7.setVisibility(View.INVISIBLE);
                button8.setVisibility(View.INVISIBLE);
                button9.setVisibility(View.INVISIBLE);

                button11.setEnabled(true);
                button12.setEnabled(true);
                button13.setEnabled(true);

                button11.setVisibility(View.VISIBLE);
                button12.setVisibility(View.VISIBLE);
                button13.setVisibility(View.VISIBLE);

                Q2_response=null;

                button5.setEnabled(true);
                button5.setVisibility(View.VISIBLE);
                button10.setEnabled(false);
                button10.setVisibility(View.INVISIBLE);
                progressBar.setProgress((progress + 20));
                progress=progress+20;

            }
        });
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView4.setText("Q4. What is the hottest planet in the solar system?");

                button11.setEnabled(false);
                button12.setEnabled(false);
                button13.setEnabled(false);

                button11.setVisibility(View.INVISIBLE);
                button12.setVisibility(View.INVISIBLE);
                button13.setVisibility(View.INVISIBLE);

                button15.setEnabled(true);
                button16.setEnabled(true);
                button17.setEnabled(true);

                button15.setVisibility(View.VISIBLE);
                button16.setVisibility(View.VISIBLE);
                button17.setVisibility(View.VISIBLE);

                Q3_response=null;

                button5.setEnabled(true);
                button5.setVisibility(View.VISIBLE);
                button14.setEnabled(false);
                button14.setVisibility(View.INVISIBLE);
                progressBar.setProgress((progress + 20));
                progress=progress+20;
            }
        });
        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView4.setText("Q5. Who gave the theory of relativity?");

                button15.setEnabled(false);
                button16.setEnabled(false);
                button17.setEnabled(false);

                button15.setVisibility(View.INVISIBLE);
                button16.setVisibility(View.INVISIBLE);
                button17.setVisibility(View.INVISIBLE);

                button19.setEnabled(true);
                button20.setEnabled(true);
                button21.setEnabled(true);

                button19.setVisibility(View.VISIBLE);
                button20.setVisibility(View.VISIBLE);
                button21.setVisibility(View.VISIBLE);

                Q4_response=null;

                button5.setEnabled(true);
                button5.setVisibility(View.VISIBLE);
                button18.setEnabled(false);
                button18.setVisibility(View.INVISIBLE);
                progressBar.setProgress((progress + 20));
                progress=progress+20;
            }
        });
    }
    public void result(View view)
    {
        Intent intent = getIntent();
        Intent intent2 = new Intent(this, MainActivity3.class);
        intent2.putExtra("score",score);
        intent2.putExtra("username",intent.getStringExtra("username"));
        startActivity(intent2);
    }
}