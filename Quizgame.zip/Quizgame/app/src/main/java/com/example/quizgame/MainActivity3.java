package com.example.quizgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    TextView textView5,textView6;

    public void exit(View view)
    {
        finish();
        moveTaskToBack(true);
    }

    public void repeat(View view)
    {
        Intent intent=getIntent();
        Intent intent3=new Intent(this,MainActivity.class);
        intent3.putExtra("username",intent.getStringExtra("username"));
        startActivity(intent3);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        textView5=findViewById(R.id.textView5);
        textView6=findViewById(R.id.textView6);

        Intent intent2=getIntent();
        int score=intent2.getIntExtra("score",0);
        String name=intent2.getStringExtra("username");
        textView6.setText(score+"/5");
        textView5.setText("Congratulations "+name+"!");
    }
}